"""Generic overlapping-tile wrapper for tiny-object proposal providers."""

from __future__ import annotations

import hashlib
import json
import tempfile
import threading
import time
from collections import OrderedDict
from collections.abc import Iterator, Mapping
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any

from PIL import Image

from .instance_postprocess import conservative_nms_indices, postprocess_instances
from .parallel import resolve_parallel_workers
from .protocol import (
    ProposalError,
    ProposalProvider,
    ProposalResult,
    canonicalize_proposals,
)
from .tile_transport import (
    cpu_prepared_batches,
    cpu_prepared_items,
    save_tile_image,
    tile_image_format,
)


def tile_starts(length: int, tile_size: int, overlap_ratio: float) -> tuple[int, ...]:
    """Return deterministic starts that cover an axis without a tiny edge tile."""

    if length < 1 or tile_size < 1:
        raise ProposalError("image length and tile_size must be positive")
    if not 0.0 <= overlap_ratio < 1.0:
        raise ProposalError("tile overlap_ratio must be in [0, 1)")
    if length <= tile_size:
        return (0,)
    step = max(1, round(tile_size * (1.0 - overlap_ratio)))
    starts = list(range(0, length - tile_size + 1, step))
    final_start = length - tile_size
    if starts[-1] != final_start:
        starts.append(final_start)
    return tuple(dict.fromkeys(starts))


def generate_tiles(
    image_width: int,
    image_height: int,
    tile_size: int,
    overlap_ratio: float,
) -> tuple[tuple[int, int, int, int], ...]:
    x_starts = tile_starts(image_width, tile_size, overlap_ratio)
    y_starts = tile_starts(image_height, tile_size, overlap_ratio)
    return tuple(
        (
            x,
            y,
            min(x + tile_size, image_width),
            min(y + tile_size, image_height),
        )
        for y in y_starts
        for x in x_starts
    )


def _iou(left: list[float], right: list[float]) -> float:
    x1 = max(left[0], right[0])
    y1 = max(left[1], right[1])
    x2 = min(left[2], right[2])
    y2 = min(left[3], right[3])
    intersection = max(0.0, x2 - x1) * max(0.0, y2 - y1)
    left_area = (left[2] - left[0]) * (left[3] - left[1])
    right_area = (right[2] - right[0]) * (right[3] - right[1])
    union = left_area + right_area - intersection
    return intersection / union if union > 0.0 else 0.0


def global_nms(
    boxes: list[list[float]],
    scores: list[float],
    threshold: float,
    *,
    top_k: int | None = None,
) -> tuple[list[list[float]], list[float], list[int]]:
    try:
        keep = conservative_nms_indices(boxes, scores, threshold)
    except ValueError as exc:
        raise ProposalError(str(exc)) from exc
    if top_k is not None:
        if top_k < 0:
            raise ProposalError("top_k must be non-negative")
        keep = keep[:top_k]
    return (
        [boxes[index] for index in keep],
        [scores[index] for index in keep],
        keep,
    )


class TiledProposalProvider:
    """Run an unaware base provider on overlapping crops and deduplicate globally."""

    provider_name = "tiled"

    def __init__(
        self,
        base_provider: ProposalProvider,
        config: Mapping[str, Any],
        *,
        base_provider_name: str,
    ) -> None:
        self.base_provider = base_provider
        self.base_provider_name = base_provider_name
        self.config = dict(config)
        self.tile_size = int(self.config.get("tile_size", 1333))
        self.overlap_ratio = float(self.config.get("overlap_ratio", 0.15))
        self.global_nms_iou = float(self.config.get("global_nms_iou", 0.4))
        self.parallel_workers_requested = self.config.get("parallel_workers", 1)
        self.parallel_max_workers = int(self.config.get("parallel_max_workers", 3))
        self.parallel_worker_vram_gb = float(self.config.get("parallel_worker_vram_gb", 4.0))
        self.parallel_vram_reserve_gb = float(self.config.get("parallel_vram_reserve_gb", 6.0))
        self.batch_size = int(
            self.config.get("batch_size", getattr(base_provider, "inference_batch_size", 1))
        )
        if self.batch_size < 1:
            raise ProposalError("tiled detector batch_size must be positive")
        self._raw_predict_batch = getattr(base_provider, "predict_batch_raw", None)
        self._normal_predict_batch = getattr(base_provider, "predict_batch", None)
        self._uses_batches = callable(self._raw_predict_batch) or callable(
            self._normal_predict_batch
        )
        self.proposal_cache_size = int(self.config.get("proposal_cache_size", 8))
        self.tile_image_format = tile_image_format(self.config.get("tile_image_format", "bmp"))
        self.tile_prefetch = bool(self.config.get("tile_prefetch", True))
        if self.proposal_cache_size < 0:
            raise ProposalError("proposal_cache_size must be non-negative")
        top_k_value = self.config.get("global_top_k")
        self.global_top_k = int(top_k_value) if top_k_value is not None else None
        if self.tile_size < 1:
            raise ProposalError("tiled detector tile_size must be positive")
        if not 0.0 <= self.overlap_ratio < 1.0:
            raise ProposalError("tiled detector overlap_ratio must be in [0, 1)")
        if not 0.0 <= self.global_nms_iou <= 1.0:
            raise ProposalError("tiled detector global_nms_iou must be in [0, 1]")
        if self.global_top_k is not None and self.global_top_k < 1:
            raise ProposalError("tiled detector global_top_k must be positive")
        tiling_identity = {
            "tile_size": self.tile_size,
            "overlap_ratio": self.overlap_ratio,
            "global_nms_iou": self.global_nms_iou,
            "global_top_k": self.global_top_k,
            "parallel_workers": str(self.parallel_workers_requested),
            "parallel_max_workers": self.parallel_max_workers,
            "batch_size": self.batch_size,
            "batched_inference": self._uses_batches,
            "instance_nms_iou": float(
                self.config.get("instance_nms_iou", max(0.6, self.global_nms_iou))
            ),
            "instance_max_refinement_regions": int(
                self.config.get("instance_max_refinement_regions", 4)
            ),
            "instance_large_box_area_fraction": float(
                self.config.get("instance_large_box_area_fraction", 0.20)
            ),
        }
        encoded = json.dumps(tiling_identity, sort_keys=True, separators=(",", ":"))
        self.tiling_sha256 = hashlib.sha256(encoded.encode("utf-8")).hexdigest()
        self.model_id = (
            f"tiled:{getattr(base_provider, 'model_id', base_provider_name)}:"
            f"{self.tiling_sha256[:12]}"
        )
        self.model_identity = {
            "provider": self.provider_name,
            "base_provider": self.base_provider_name,
            "base_model_identity": getattr(base_provider, "model_identity", None),
            "base_model_id": str(getattr(base_provider, "model_id", self.base_provider_name)),
            "tiling": tiling_identity,
            "tiling_sha256": self.tiling_sha256,
        }
        self._parallel_workers: int | None = None
        self._parallel_lock = threading.Lock()
        self._proposal_cache: OrderedDict[tuple[str, int, int, str], ProposalResult] = OrderedDict()
        self._proposal_cache_lock = threading.Lock()

    def _resolved_parallel_workers(self) -> int:
        if self._uses_batches:
            return 1
        if self._parallel_workers is not None:
            return self._parallel_workers
        with self._parallel_lock:
            if self._parallel_workers is None:
                self._parallel_workers = resolve_parallel_workers(
                    self.parallel_workers_requested,
                    max_workers=self.parallel_max_workers,
                    worker_vram_gb=self.parallel_worker_vram_gb,
                    vram_reserve_gb=self.parallel_vram_reserve_gb,
                )
        assert self._parallel_workers is not None
        return self._parallel_workers

    def _proposal_cache_key(
        self, image_path: Path, target_phrase: str
    ) -> tuple[str, int, int, str]:
        stat = image_path.stat()
        return (
            str(image_path),
            int(stat.st_size),
            int(stat.st_mtime_ns),
            target_phrase.strip().casefold(),
        )

    def _cached_proposal(self, key: tuple[str, int, int, str]) -> ProposalResult | None:
        if self.proposal_cache_size == 0:
            return None
        with self._proposal_cache_lock:
            result = self._proposal_cache.get(key)
            if result is not None:
                self._proposal_cache.move_to_end(key)
            return result

    def _cache_proposal(self, key: tuple[str, int, int, str], result: ProposalResult) -> None:
        if self.proposal_cache_size == 0:
            return
        with self._proposal_cache_lock:
            self._proposal_cache[key] = result
            self._proposal_cache.move_to_end(key)
            while len(self._proposal_cache) > self.proposal_cache_size:
                self._proposal_cache.popitem(last=False)

    @staticmethod
    def _cache_view(
        result: ProposalResult, *, cache_hit: bool, latency_ms: float
    ) -> ProposalResult:
        metadata = dict(result.metadata)
        metadata.update(
            {
                "proposal_cache_hit": cache_hit,
                "base_latency_ms": (0.0 if cache_hit else metadata.get("base_latency_ms", 0.0)),
                "wrapper_latency_ms": latency_ms,
            }
        )
        return ProposalResult(
            boxes_xyxy=[list(box) for box in result.boxes_xyxy],
            scores=list(result.scores),
            latency_ms=latency_ms,
            provider=result.provider,
            model_id=result.model_id,
            metadata=metadata,
        )

    def predict(self, image_path: Path, target_phrase: str) -> ProposalResult:
        resolved_image = Path(image_path).expanduser().resolve()
        if not resolved_image.is_file():
            raise ProposalError(f"tiled detector image does not exist: {resolved_image}")
        started = time.perf_counter()
        cache_key = self._proposal_cache_key(resolved_image, target_phrase)
        cached = self._cached_proposal(cache_key)
        if cached is not None:
            return self._cache_view(
                cached,
                cache_hit=True,
                latency_ms=(time.perf_counter() - started) * 1000.0,
            )
        raw_boxes: list[list[float]] = []
        raw_scores: list[float] = []
        raw_records: list[dict[str, Any]] = []
        tile_records: list[dict[str, Any]] = []
        base_latency_ms = 0.0
        batch_count = 0
        parallel_workers = self._resolved_parallel_workers()
        with Image.open(resolved_image) as source:
            image = source.convert("RGB")
        # RGB owns its pixels; release the decoded source before inference starts.
        source.close()
        with image:
            tiles = generate_tiles(
                image.width,
                image.height,
                self.tile_size,
                self.overlap_ratio,
            )
            with tempfile.TemporaryDirectory(prefix="uhr_tiled_detector_") as temporary:
                temporary_root = Path(temporary)

                def prepare_tile(
                    item: tuple[int, tuple[int, int, int, int]],
                ) -> tuple[int, tuple[int, int, int, int], Path]:
                    tile_index, coordinates = item
                    tile_path = temporary_root / (f"tile_{tile_index:05d}.{self.tile_image_format}")
                    crop = image.crop(coordinates)
                    try:
                        save_tile_image(crop, tile_path, self.tile_image_format)
                    finally:
                        crop.close()
                    return tile_index, coordinates, tile_path

                def release_tile(item: tuple[int, tuple[int, int, int, int], Path]) -> None:
                    item[2].unlink(missing_ok=True)

                def predict_tile(
                    item: tuple[int, tuple[int, int, int, int], Path],
                ) -> Any:
                    raw_predict = getattr(self.base_provider, "predict_raw", None)
                    predictor = raw_predict if callable(raw_predict) else self.base_provider.predict
                    return finish_tile(item, predictor(item[2], target_phrase))

                def finish_tile(
                    item: tuple[int, tuple[int, int, int, int], Path], result: ProposalResult
                ) -> tuple[
                    int,
                    tuple[int, int, int, int],
                    ProposalResult,
                    list[list[float]],
                    list[float],
                    dict[str, int],
                ]:
                    tile_index, coordinates, _tile_path = item
                    x1, y1, x2, y2 = coordinates
                    local_boxes, local_scores, validation = canonicalize_proposals(
                        result.boxes_xyxy,
                        result.scores,
                        image_width=x2 - x1,
                        image_height=y2 - y1,
                    )
                    return (
                        tile_index,
                        coordinates,
                        result,
                        local_boxes,
                        local_scores,
                        validation,
                    )

                lane_count = min(parallel_workers, len(tiles))
                inputs = iter(enumerate(tiles))
                inputs_lock = threading.Lock()

                def lane_inputs() -> Iterator[tuple[int, tuple[int, int, int, int]]]:
                    while True:
                        with inputs_lock:
                            item = next(inputs, None)
                        if item is None:
                            return
                        yield item

                def predict_lane(_lane: int) -> list[Any]:
                    # One CPU lookahead per existing inference worker; no new GPU consumer.
                    with cpu_prepared_items(
                        lane_inputs(), prepare_tile, release_tile, prefetch=self.tile_prefetch
                    ) as prepared:
                        return [predict_tile(item) for item in prepared]

                tile_results: list[Any]
                if self._uses_batches:
                    tile_results = []
                    batch_predict = (
                        self._raw_predict_batch
                        if callable(self._raw_predict_batch)
                        else self._normal_predict_batch
                    )
                    if not callable(batch_predict):
                        raise ProposalError("tiled batch provider has no batch prediction method")
                    with cpu_prepared_batches(
                        enumerate(tiles),
                        prepare_tile,
                        release_tile,
                        batch_size=self.batch_size,
                        prefetch=self.tile_prefetch,
                    ) as batches:
                        for batch in batches:
                            results = batch_predict(
                                [item[2] for item in batch], target_phrase
                            )
                            if len(results) != len(batch):
                                raise ProposalError("tiled batch result count mismatch")
                            batch_count += 1
                            tile_results.extend(
                                finish_tile(item, result)
                                for item, result in zip(batch, results, strict=True)
                            )
                elif lane_count == 1:
                    tile_results = predict_lane(0)
                else:
                    with ThreadPoolExecutor(
                        max_workers=lane_count,
                        thread_name_prefix="tiled-detector",
                    ) as executor:
                        lanes = executor.map(predict_lane, range(lane_count))
                        tile_results = [item for lane in lanes for item in lane]
                    tile_results.sort(key=lambda item: item[0])

                for (
                    tile_index,
                    coordinates,
                    result,
                    local_boxes,
                    local_scores,
                    validation,
                ) in tile_results:
                    x1, y1, x2, y2 = coordinates
                    base_latency_ms += result.latency_ms
                    tile_records.append(
                        {
                            "tile_id": tile_index,
                            "tile_xyxy": [x1, y1, x2, y2],
                            "raw_proposal_count": len(result.boxes_xyxy),
                            "valid_proposal_count": len(local_boxes),
                            "base_latency_ms": result.latency_ms,
                            "base_provider": result.provider,
                            "base_model_id": result.model_id,
                            "effective_batch_size": result.metadata.get("effective_batch_size", 1),
                            "batch_oom_retries": result.metadata.get("batch_oom_retries", 0),
                            "validation": validation,
                            "candidate_pool_complete": result.metadata.get(
                                "candidate_pool_complete"
                            )
                            is not False
                            and not result.metadata.get("candidate_truncated")
                            and validation["invalid_count"] == 0,
                            "candidate_truncated": bool(result.metadata.get("candidate_truncated")),
                        }
                    )
                    for local_box, score in zip(local_boxes, local_scores, strict=True):
                        global_box = [
                            local_box[0] + x1,
                            local_box[1] + y1,
                            local_box[2] + x1,
                            local_box[3] + y1,
                        ]
                        raw_index = len(raw_boxes)
                        raw_boxes.append(global_box)
                        raw_scores.append(score)
                        raw_records.append(
                            {
                                "raw_index": raw_index,
                                "tile_id": tile_index,
                                "local_box_xyxy": local_box,
                                "global_box_xyxy": global_box,
                                "score": score,
                            }
                        )
        source_ids = [int(record["raw_index"]) for record in raw_records]
        tile_by_id = {int(tile["tile_id"]): tile for tile in tile_records}
        reference_areas = [
            float(
                (tile_by_id[int(record["tile_id"])]["tile_xyxy"][2]
                 - tile_by_id[int(record["tile_id"])]["tile_xyxy"][0])
                * (tile_by_id[int(record["tile_id"])]["tile_xyxy"][3]
                   - tile_by_id[int(record["tile_id"])]["tile_xyxy"][1])
            )
            for record in raw_records
        ]

        def refine_region(parent: list[float]) -> tuple[list[list[float]], list[float]]:
            from PIL import Image

            padding = float(self.config.get("instance_refinement_padding_ratio", 0.12))
            with Image.open(resolved_image) as source:
                source_image = source.convert("RGB")
            try:
                image_width, image_height = source_image.size
                pad_x = max(8, round((parent[2] - parent[0]) * padding))
                pad_y = max(8, round((parent[3] - parent[1]) * padding))
                crop_box = (
                    max(0, int(parent[0] - pad_x)),
                    max(0, int(parent[1] - pad_y)),
                    min(image_width, int(parent[2] + pad_x + 0.999)),
                    min(image_height, int(parent[3] + pad_y + 0.999)),
                )
                with tempfile.TemporaryDirectory(prefix="uhr_instance_refine_") as temp_dir:
                    crop_path = Path(temp_dir) / f"refine.{self.tile_image_format}"
                    crop = source_image.crop(crop_box)
                    try:
                        save_tile_image(crop, crop_path, self.tile_image_format)
                    finally:
                        crop.close()
                    raw_predict = getattr(self.base_provider, "predict_raw", None)
                    predictor = raw_predict if callable(raw_predict) else self.base_provider.predict
                    refined = predictor(crop_path, target_phrase)
            finally:
                source_image.close()
            dx, dy = crop_box[0], crop_box[1]
            mapped = [
                [box[0] + dx, box[1] + dy, box[2] + dx, box[3] + dy]
                for box in refined.boxes_xyxy
            ]
            return mapped, list(refined.scores)

        instance_nms_iou = float(
            self.config.get("instance_nms_iou", max(0.6, self.global_nms_iou))
        )
        boxes, scores, instance_trace = postprocess_instances(
            raw_boxes,
            raw_scores,
            nms_iou=instance_nms_iou,
            source_ids=source_ids,
            source_groups=[int(record["tile_id"]) for record in raw_records],
            reference_areas=reference_areas,
            refine=refine_region,
            max_refinement_regions=int(self.config.get("instance_max_refinement_regions", 4)),
            large_box_area_fraction=float(
                self.config.get("instance_large_box_area_fraction", 0.20)
            ),
        )
        final_source_ids = list(instance_trace["final_source_ids"])
        # Refinement children inherit the parent's raw proposal id. This keeps
        # the existing source trace shape while the detailed split is recorded
        # separately in ``instance_postprocess``.
        keep = [int(source_id) for source_id in final_source_ids if source_id is not None]
        before_global_top_k = len(boxes)
        if self.global_top_k is not None:
            boxes = boxes[: self.global_top_k]
            scores = scores[: self.global_top_k]
            keep = keep[: self.global_top_k]
        latency_ms = (time.perf_counter() - started) * 1000.0
        result = ProposalResult(
            boxes_xyxy=boxes,
            scores=scores,
            latency_ms=latency_ms,
            provider=self.provider_name,
            model_id=self.model_id,
            metadata={
                "schema_version": "uhr-tiled-proposals-v1",
                "coordinate_mode": "absolute_original_pixel_xyxy",
                "target_phrase": target_phrase,
                "base_provider": self.base_provider_name,
                "base_model_id": str(
                    getattr(self.base_provider, "model_id", self.base_provider_name)
                ),
                "model_identity": self.model_identity,
                "tile_size": self.tile_size,
                "overlap_ratio": self.overlap_ratio,
                "tile_image_format": self.tile_image_format,
                "tile_prefetch": self.tile_prefetch,
                "batch_size": self.batch_size if self._uses_batches else 1,
                "batch_count": batch_count,
                "batched_inference": self._uses_batches,
                "cpu_lookahead_unit": "batch" if self._uses_batches else "tile",
                "cpu_lookahead_per_worker": 1 if self.tile_prefetch else 0,
                "global_nms_iou": self.global_nms_iou,
                "parallel_workers_requested": str(self.parallel_workers_requested),
                "parallel_workers": parallel_workers,
                "parallel_max_workers": self.parallel_max_workers,
                "proposal_cache_hit": False,
                "proposal_cache_size": self.proposal_cache_size,
                "tile_count": len(tile_records),
                "tiles": tile_records,
                "raw_proposal_count": len(raw_boxes),
                "deduplicated_proposal_count": len(boxes),
                "candidate_truncated": any(tile["candidate_truncated"] for tile in tile_records)
                or (self.global_top_k is not None and before_global_top_k > len(boxes)),
                "candidate_pool_complete": all(
                    tile["candidate_pool_complete"] for tile in tile_records
                )
                and (
                    self.global_top_k is None
                    or (
                        before_global_top_k <= self.global_top_k
                        and before_global_top_k == len(boxes)
                    )
                ),
                "raw_proposals": raw_records,
                "kept_raw_indices": keep,
                "instance_postprocess": instance_trace,
                "instance_search_regions": instance_trace["aggregate_regions"],
                "unresolved_instance_regions": instance_trace["unresolved_regions"],
                "instance_resolution_complete": instance_trace[
                    "instance_resolution_complete"
                ],
                "base_latency_ms": base_latency_ms,
                "wrapper_latency_ms": latency_ms,
            },
        )
        self._cache_proposal(cache_key, result)
        return result

    def close(self) -> None:
        self.base_provider.close()
        with self._proposal_cache_lock:
            self._proposal_cache.clear()
