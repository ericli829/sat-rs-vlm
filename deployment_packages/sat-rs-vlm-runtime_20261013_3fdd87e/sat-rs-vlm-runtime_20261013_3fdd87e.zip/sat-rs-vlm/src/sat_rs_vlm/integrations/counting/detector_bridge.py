"""Old counting_system Detector interface backed by the current ProposalProvider."""

from __future__ import annotations

import tempfile
from collections.abc import Iterable, Iterator
from dataclasses import dataclass
from itertools import groupby
from pathlib import Path
from typing import cast

from sat_rs_vlm.integrations.detectors.protocol import (
    BatchedProposalProvider,
    ProposalError,
    ProposalProvider,
    ProposalResult,
)
from sat_rs_vlm.integrations.detectors.tile_transport import (
    cpu_prepared_batches,
    cpu_prepared_items,
    save_tile_image,
    tile_image_format,
)

from .bootstrap import ensure_counting_system_importable

ensure_counting_system_importable()

from counting_system.detector.base import DetectionRequest, DetectionResponse  # noqa: E402
from counting_system.geometry import local_to_global  # noqa: E402
from counting_system.runtime import Detection  # noqa: E402


@dataclass(frozen=True)
class _PreparedTile:
    path: Path
    phrase: str
    local_size: tuple[int, int]
    crop_xyxy: tuple[float, float, float, float]
    label: str
    tile_id: str
    scale_id: str
    spatial_resize_enabled: bool | None
    score_threshold: float


class CountingProposalDetectorBridge:
    """Tile crop → ProposalProvider inference → original-image XYXY Detection.

    Counting System owns Global/Native/Fine tiling. The wrapped provider must
    be a non-tiled sidecar such as ``lae_dino_lae1m``.
    """

    name = "proposal_bridge"

    def __init__(
        self, provider: ProposalProvider, *, image_format: str = "bmp", prefetch: bool = True
    ) -> None:
        self._provider = provider
        self.provider_name = getattr(provider, "provider_name", "proposal")
        self.name = self.provider_name
        self.impl_name = self.provider_name
        self.tile_image_format = tile_image_format(image_format)
        self.tile_prefetch = prefetch
        self.call_count = 0
        self.batch_size = int(getattr(provider, "inference_batch_size", 1))

    def detect(self, request: DetectionRequest) -> DetectionResponse:
        with tempfile.TemporaryDirectory(prefix="counting_tile_") as temp_dir:
            tile_path = Path(temp_dir) / f"tile.{self.tile_image_format}"
            return self._predict_prepared(self._prepare(request, tile_path))

    def _prepare(self, request: DetectionRequest, tile_path: Path) -> _PreparedTile:
        phrase = request.texts or request.target.detection_phrase()
        save_tile_image(request.image, tile_path, self.tile_image_format)
        return _PreparedTile(
            tile_path,
            phrase,
            request.image.size,
            request.tile.crop_xyxy,
            request.target.name,
            request.tile.tile_id,
            request.tile.scale_id,
            request.tile.spatial_resize_enabled,
            request.score_threshold,
        )

    def detect_many(self, requests: Iterable[DetectionRequest]) -> Iterator[DetectionResponse]:
        """One GPU consumer, with one CPU lookahead batch (legacy: one tile)."""

        def indexed_requests() -> Iterator[tuple[int, DetectionRequest]]:
            source = iter(requests)
            try:
                yield from enumerate(source)
            finally:
                close = getattr(source, "close", None)
                if callable(close):
                    close()

        with tempfile.TemporaryDirectory(prefix="counting_tiles_") as temp_dir:
            root = Path(temp_dir)

            def prepare(item: tuple[int, DetectionRequest]) -> _PreparedTile:
                index, request = item
                return self._prepare(request, root / f"tile_{index:05d}.{self.tile_image_format}")

            def release(tile: _PreparedTile) -> None:
                tile.path.unlink(missing_ok=True)

            if callable(getattr(self._provider, "predict_batch", None)):
                with cpu_prepared_batches(
                    indexed_requests(),
                    prepare,
                    release,
                    batch_size=self.batch_size,
                    prefetch=self.tile_prefetch,
                ) as batches:
                    for batch in batches:
                        # Keep query roles and padding shape bounded without
                        # collecting raw requests whose source owns their images.
                        for _, grouped in groupby(
                            batch,
                            key=lambda t: (
                                t.phrase,
                                t.local_size,
                                t.spatial_resize_enabled,
                                t.score_threshold,
                            ),
                        ):
                            tiles = list(grouped)
                            self.call_count += len(tiles)
                            try:
                                provider = cast(BatchedProposalProvider, self._provider)
                                raw_predict = getattr(provider, "predict_batch_raw", None)
                                if tiles[0].spatial_resize_enabled is not None and callable(
                                    raw_predict
                                ):
                                    results = raw_predict(
                                        [tile.path for tile in tiles],
                                        tiles[0].phrase,
                                        options={
                                            "spatial_resize_enabled": tiles[
                                                0
                                            ].spatial_resize_enabled,
                                            "score_threshold": tiles[0].score_threshold,
                                        },
                                    )
                                else:
                                    results = provider.predict_batch(
                                        [tile.path for tile in tiles], tiles[0].phrase
                                    )
                            except Exception as exc:
                                raise RuntimeError(f"LAE sidecar batch failure: {exc}") from exc
                            if len(results) != len(tiles):
                                raise RuntimeError("LAE sidecar batch result count mismatch")
                            for tile, result in zip(tiles, results, strict=True):
                                yield self._response(tile, result)
            else:
                with cpu_prepared_items(
                    indexed_requests(), prepare, release, prefetch=self.tile_prefetch
                ) as prepared:
                    for tile in prepared:
                        yield self._predict_prepared(tile)

    def _predict_prepared(self, tile: _PreparedTile) -> DetectionResponse:
        # Retain a scalar diagnostic, never requests that own full tile images.
        self.call_count += 1
        try:
            raw_predict = getattr(self._provider, "predict_raw", None)
            if tile.spatial_resize_enabled is not None and callable(raw_predict):
                result = raw_predict(
                    tile.path,
                    tile.phrase,
                    options={
                        "spatial_resize_enabled": tile.spatial_resize_enabled,
                        "score_threshold": tile.score_threshold,
                    },
                )
            else:
                result = self._provider.predict(tile.path, tile.phrase)
        except ProposalError as exc:
            raise RuntimeError(f"LAE sidecar failure: {exc}") from exc
        except Exception as exc:
            raise RuntimeError(
                f"Counting provider unavailable: LAE sidecar failure: {exc}"
            ) from exc
        return self._response(tile, result)

    def _response(self, tile: _PreparedTile, result: ProposalResult) -> DetectionResponse:
        local_w, local_h = tile.local_size
        detections: list[Detection] = []
        for index, (box, score) in enumerate(zip(result.boxes_xyxy, result.scores, strict=True)):
            global_box = local_to_global(box, tile.crop_xyxy, local_size=(local_w, local_h))
            detections.append(
                Detection(
                    bbox_xyxy_global=global_box,
                    score=float(score),
                    label=tile.label,
                    tile_id=tile.tile_id,
                    scale_id=tile.scale_id,
                    provenance={
                        "backend": self.impl_name,
                        "local_xyxy": [float(value) for value in box],
                        "crop_xyxy": list(tile.crop_xyxy),
                        "local_size": [local_w, local_h],
                        "coordinate_mode": "absolute_original_pixel_xyxy",
                        "model_id": result.model_id,
                        "candidate_id": f"{tile.tile_id}:proposal:{index + 1}",
                        "instance_status": "CONFIRMED_INSTANCE",
                    },
                )
            )
        return DetectionResponse(
            detections=detections,
            raw_count=len(detections),
            backend=self.impl_name,
            extra={"proposal_metadata": dict(result.metadata)},
        )

    def close(self) -> None:
        self._provider.close()
