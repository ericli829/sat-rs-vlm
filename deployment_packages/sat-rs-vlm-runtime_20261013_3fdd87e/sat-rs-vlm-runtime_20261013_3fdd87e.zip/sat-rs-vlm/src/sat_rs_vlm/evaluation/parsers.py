"""与 sat-rs-vlm@449bc857 字段约定兼容的独立解析器。"""

from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class JsonObjectResult:
    payload: dict[str, Any] | None
    strict_json: bool
    reason: str | None


@dataclass(frozen=True)
class GroundingParseResult:
    label: str | None
    bbox: tuple[float, float, float, float] | None
    valid_json: bool
    parse_ok: bool
    coordinate_valid: bool
    parse_error: str | None
    coordinate_error: str | None


@dataclass(frozen=True)
class CountParseResult:
    value: int | None
    reason: str | None = None


@dataclass(frozen=True)
class ChangePredictionResult:
    value: int | None
    normalized_text: str
    reason: str | None = None
    match_type: str | None = None


_INTEGER_PATTERN = re.compile(r"(?<![\w.])-?\d+(?![\w.])")
_WORD_TOKEN_PATTERN = re.compile(r"[a-z]+")
_ZERO_PHRASES = re.compile(r"\b(?:no|none|nothing|zero)\b", re.IGNORECASE)
_SMALL_NUMBERS = {
    "zero": 0,
    "one": 1,
    "two": 2,
    "three": 3,
    "four": 4,
    "five": 5,
    "six": 6,
    "seven": 7,
    "eight": 8,
    "nine": 9,
    "ten": 10,
    "eleven": 11,
    "twelve": 12,
    "thirteen": 13,
    "fourteen": 14,
    "fifteen": 15,
    "sixteen": 16,
    "seventeen": 17,
    "eighteen": 18,
    "nineteen": 19,
}
_TENS = {
    "twenty": 20,
    "thirty": 30,
    "forty": 40,
    "fifty": 50,
    "sixty": 60,
    "seventy": 70,
    "eighty": 80,
    "ninety": 90,
}

_NO_CHANGE_EXPRESSIONS = {
    "no change has occurred",
    "no change occurred",
    "no changes have occurred",
    "there is no change",
    "there are no changes",
    "there is no difference",
    "no difference",
    "the two scenes seem identical",
    "the two scenes are identical",
    "the scene is the same as before",
    "the scene remains the same as before",
    "almost nothing has changed",
    "nothing has changed",
    "unchanged",
}
_CONTEXTUAL_NO_CHANGE_EXPRESSIONS = {"no change", *_NO_CHANGE_EXPRESSIONS}

# Parser versions are deliberately independent: legacy evaluation keeps its
# historical exact-expression behavior, while the contextual parser is used
# only by the v1.8 server/local semantic workflow.
LEGACY_CHANGE_PARSER_VERSION = "legacy_exact_no_change_v1"
CONTEXTUAL_CHANGE_PARSER_VERSION = "levir_contextual_no_change_v3"
CHANGE_PARSER_VERSION = CONTEXTUAL_CHANGE_PARSER_VERSION
CHANGE_DECISION_VERSION = "explicit_binary_priority_v1"

_ANSWER_PREFIX_PATTERN = re.compile(r"^(?:(?:the )?answer|prediction|result)(?: is)? ")
_NO_CHANGE_QUALIFIER = (
    r"(?:(?:significant|visible|discernible|detectable|observable|noticeable|"
    r"obvious|major|meaningful|notable|substantial|apparent) )?"
)
_GLOBAL_SCOPE = (
    r"(?: (?:between|across|in) (?:the )?"
    r"(?:(?:two|both|first and second|second and first) )?"
    r"(?:images?|scenes?|pictures?|views?|area|region))?"
)
_NO_CHANGE_PREDICATE = (
    r"(?:"
    r" (?:has|have) occurred"
    r"| occurred"
    r"| (?:observed|detected|seen|found|noticed)"
    r"| (?:has|have) been (?:observed|detected|seen|found|noticed)"
    r"| (?:is|are|was|were|can be|could be) "
    r"(?:observed|detected|seen|found|noticed|visible|apparent)"
    r")?"
)
_GLOBAL_IMAGE_SUBJECT = (
    r"(?:the )?(?:(?:two|both|first and second|second and first) )?"
    r"(?:images?|scenes?|pictures?|views?)"
)
_NO_CHANGE_PATTERNS = tuple(
    re.compile(pattern)
    for pattern in (
        (
            rf"(?:there (?:is|are|was|were|has been|have been) )?no "
            rf"{_NO_CHANGE_QUALIFIER}(?:changes?|differences?)"
            rf"{_NO_CHANGE_PREDICATE}{_GLOBAL_SCOPE}"
        ),
        (
            rf"{_GLOBAL_IMAGE_SUBJECT} "
            rf"(?:is|are|was|were|remain|remains|remained|appear|appears|appeared|"
            r"seem|seems|seemed|look|looks|looked) "
            r"(?:identical|unchanged|the same(?: as before)?)"
        ),
        (
            r"the (?:first|second) (?:image|scene|picture|view) "
            r"(?:is|was|appears|appeared|seems|seemed|looks|looked) "
            r"(?:identical to|the same as) the "
            r"(?:first|second) (?:image|scene|picture|view)"
        ),
        (
            r"(?:the )?(?:scene|area|region|landscape) "
            r"(?:is|was|remains|remained|appears|appeared|seems|seemed) "
            r"(?:unchanged|the same(?: as before)?)"
        ),
        rf"{_GLOBAL_IMAGE_SUBJECT} (?:has|have|had) not changed",
        r"(?:the )?(?:scene|area|region|landscape) (?:has|had) not changed",
        r"(?:almost )?nothing (?:has |had )?changed",
        (
            rf"{_GLOBAL_IMAGE_SUBJECT} "
            rf"(?:show|shows|showed|indicate|indicates|indicated) no "
            rf"{_NO_CHANGE_QUALIFIER}(?:changes?|differences?)"
        ),
    )
)
_CLAUSE_SEPARATOR_PATTERN = re.compile(r"[.!?;\n]+")
_CONTEXTUAL_NO_CHANGE_PATTERNS = tuple(
    re.compile(pattern)
    for pattern in (
        rf"\bno {_NO_CHANGE_QUALIFIER}(?:changes?|differences?)\b",
        (
            r"\b(?:the )?(?:(?:two|both|first and second|second and first) )?"
            r"(?:images|scenes|pictures|views) "
            r"(?:are|were|remain|remained|appear|appeared|seem|seemed|look|looked) "
            r"(?:identical|unchanged|the same)\b"
        ),
        (
            r"\bthe (?:first|second) (?:image|scene|picture|view) "
            r"(?:is|was|appears|appeared|seems|seemed|looks|looked) "
            r"(?:identical to|the same as) the "
            r"(?:first|second) (?:image|scene|picture|view)\b"
        ),
        r"\b(?:the )?(?:overall )?(?:scene|landscape|area) remains? (?:unchanged|the same)\b",
        r"\b(?:almost )?nothing (?:has |had )?changed\b",
    )
)
_POSITIVE_CHANGE_EVIDENCE_PATTERNS = tuple(
    re.compile(pattern)
    for pattern in (
        (
            r"\b(?:shows?|showed|indicates?|indicated|describes?|described) "
            r"(?:a |an |the )?(?:(?:significant|noticeable|visible|clear|major) )?"
            r"change\b"
        ),
        r"\b(?:main|primary|most noticeable|significant|noticeable|major) change\b",
        (
            r"\b(?:appeared|disappeared|removed|added|replaced|demolished|constructed|"
            r"built|altered|destroyed|expanded|reduced)\b"
        ),
        (
            r"\b(?:is|are|was|were|has been|have been|had been) "
            r"(?:changed|altered|removed|added|replaced|demolished|constructed|built)\b"
        ),
        (
            r"\b(?:new|additional) (?:building|house|road|street|vehicle|car|truck|"
            r"structure|path|pond|pool|field|facility|construction|development)\b"
        ),
        r"\b(?:not present|no longer present|no longer visible|now absent)\b",
        r"\bdifferent (?:bend|color|layout|position|appearance|shape|roof|surface|texture)\b",
        r"\bnot (?:directly )?related\b",
    )
)
_STRUCTURED_CHANGE_KEYS = ("changeflag", "change_flag", "changed", "has_change")


def extract_json_object(text: str) -> JsonObjectResult:
    """解析纯 JSON、Markdown code fence 或混合文本中的首个 JSON object。"""

    stripped = text.strip()
    if not stripped:
        return JsonObjectResult(None, False, "empty_text")
    try:
        payload = json.loads(stripped)
    except json.JSONDecodeError:
        payload = None
    if isinstance(payload, dict):
        return JsonObjectResult(payload, True, None)

    fenced = re.search(
        r"```(?:json)?\s*(\{.*?\})\s*```",
        stripped,
        flags=re.IGNORECASE | re.DOTALL,
    )
    if fenced:
        try:
            payload = json.loads(fenced.group(1))
        except json.JSONDecodeError:
            payload = None
        if isinstance(payload, dict):
            return JsonObjectResult(payload, False, None)

    decoder = json.JSONDecoder()
    for start, character in enumerate(stripped):
        if character != "{":
            continue
        try:
            payload, _ = decoder.raw_decode(stripped[start:])
        except json.JSONDecodeError:
            continue
        if isinstance(payload, dict):
            return JsonObjectResult(payload, False, None)
    return JsonObjectResult(None, False, "json_object_not_found")


def _normalize_bbox(
    values: list[float],
    coordinate_format: str | None,
    image_size: tuple[int, int] | None,
) -> tuple[tuple[float, float, float, float], bool, str | None]:
    def bbox_tuple(items: list[float]) -> tuple[float, float, float, float]:
        return (float(items[0]), float(items[1]), float(items[2]), float(items[3]))

    if coordinate_format is None:
        return bbox_tuple(values), False, "coordinate_format_unresolved"
    if coordinate_format == "normalized_0_1":
        scaled = values
    elif coordinate_format == "percent_0_100":
        scaled = [value / 100.0 for value in values]
    elif coordinate_format == "scaled_0_1000":
        scaled = [value / 1000.0 for value in values]
    elif coordinate_format == "pixel_xyxy":
        if image_size is None or image_size[0] <= 0 or image_size[1] <= 0:
            return bbox_tuple(values), False, "pixel_coordinates_require_image_size"
        width, height = image_size
        scaled = [
            values[0] / width,
            values[1] / height,
            values[2] / width,
            values[3] / height,
        ]
    else:
        return bbox_tuple(values), False, f"unsupported_coordinate_format:{coordinate_format}"

    bbox = bbox_tuple(scaled)
    x_min, y_min, x_max, y_max = bbox
    if not all(0.0 <= value <= 1.0 for value in bbox):
        return bbox, False, "bbox_out_of_range"
    if not (x_min < x_max and y_min < y_max):
        return bbox, False, "bbox_not_strict_xyxy"
    return bbox, True, None


def parse_grounding(
    value: Any,
    *,
    coordinate_format: str | None,
    image_size: tuple[int, int] | None = None,
) -> GroundingParseResult:
    """解析单目标 label+bbox，并将显式坐标格式转换到 normalized_0_1。"""

    extracted = (
        JsonObjectResult(value, True, None)
        if isinstance(value, dict)
        else extract_json_object(str(value))
    )
    payload = extracted.payload
    if payload is None:
        return GroundingParseResult(
            None,
            None,
            False,
            False,
            False,
            extracted.reason,
            None,
        )

    label_value = payload.get("label")
    bbox_value = payload.get("bbox")
    if label_value is None or bbox_value is None:
        labels = payload.get("labels")
        boxes = payload.get("boxes")
        if not isinstance(labels, list) or not isinstance(boxes, list):
            return GroundingParseResult(
                None, None, True, False, False, "label_or_bbox_missing", None
            )
        if len(labels) != 1 or len(boxes) != 1:
            return GroundingParseResult(
                None, None, True, False, False, "legacy_schema_must_have_one_target", None
            )
        label_value = labels[0]
        bbox_value = boxes[0]

    label = str(label_value).strip().lower()
    if not label:
        return GroundingParseResult(None, None, True, False, False, "empty_label", None)
    if not isinstance(bbox_value, (list, tuple)) or len(bbox_value) != 4:
        return GroundingParseResult(
            label, None, True, False, False, "bbox_must_have_four_values", None
        )
    try:
        raw_bbox = [float(item) for item in bbox_value]
    except (TypeError, ValueError):
        return GroundingParseResult(
            label, None, True, False, False, "bbox_contains_non_numeric_value", None
        )
    if not all(math.isfinite(item) for item in raw_bbox):
        return GroundingParseResult(
            label, None, True, False, False, "bbox_contains_non_finite_value", None
        )
    bbox, coordinate_valid, coordinate_error = _normalize_bbox(
        raw_bbox,
        coordinate_format,
        image_size,
    )
    return GroundingParseResult(
        label,
        bbox,
        True,
        True,
        coordinate_valid,
        None,
        coordinate_error,
    )


def _parse_number_words(text: str) -> list[int]:
    tokens = _WORD_TOKEN_PATTERN.findall(text.lower().replace("-", " "))
    results: list[int] = []
    index = 0
    while index < len(tokens):
        token = tokens[index]
        if token not in _SMALL_NUMBERS and token not in _TENS:
            index += 1
            continue
        value = 0
        consumed = False
        while index < len(tokens):
            token = tokens[index]
            if token in _SMALL_NUMBERS:
                value += _SMALL_NUMBERS[token]
            elif token in _TENS:
                value += _TENS[token]
            elif token == "hundred" and consumed:
                value *= 100
            elif token == "and" and consumed:
                index += 1
                continue
            else:
                break
            consumed = True
            index += 1
        if consumed:
            results.append(value)
    return results


def parse_count(value: Any) -> CountParseResult:
    """把结构化或自然语言计数转换为唯一非负整数。"""

    if isinstance(value, bool):
        return CountParseResult(None, "boolean_is_not_count")
    if isinstance(value, int):
        return CountParseResult(value) if value >= 0 else CountParseResult(None, "negative_count")
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer() or value < 0:
            return CountParseResult(None, "count_must_be_non_negative_integer")
        return CountParseResult(int(value))
    if isinstance(value, dict):
        if "count" not in value:
            return CountParseResult(None, "count_field_missing")
        return parse_count(value["count"])

    text = str(value).strip()
    if not text:
        return CountParseResult(None, "empty_count")
    payload = extract_json_object(text).payload
    if payload is not None and "count" in payload:
        return parse_count(payload["count"])

    digit_values = [int(match.group(0)) for match in _INTEGER_PATTERN.finditer(text)]
    if digit_values:
        unique = set(digit_values)
        if len(unique) != 1:
            return CountParseResult(None, "ambiguous_multiple_counts")
        return parse_count(digit_values[0])
    word_values = _parse_number_words(text)
    if word_values:
        unique = set(word_values)
        if len(unique) != 1:
            return CountParseResult(None, "ambiguous_multiple_counts")
        return parse_count(word_values[0])
    if _ZERO_PHRASES.search(text):
        return CountParseResult(0)
    return CountParseResult(None, "count_unresolved")


def normalize_text(text: str) -> str:
    """与当前仓库一致：小写、去引号和标点、压缩空白。"""

    value = re.sub(r"[\"'`]", "", text.strip().lower())
    value = re.sub(r"[^\w\u4e00-\u9fff]+", " ", value, flags=re.UNICODE)
    return re.sub(r"\s+", " ", value).strip()


def _binary_change_value(value: Any) -> int | None:
    """Parse an explicitly binary change value without caption-level inference."""

    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (int, float)) and value in {0, 1}:
        return int(value)
    if isinstance(value, str):
        normalized = normalize_text(value).replace("_", " ")
        if normalized in {"0", "no", "false", "no change", "unchanged"}:
            return 0
        if normalized in {"1", "yes", "true", "change", "changed", "has change"}:
            return 1
    return None


def parse_explicit_change_prediction(text: str) -> ChangePredictionResult:
    """Parse only an explicit binary answer, without caption-level inference."""

    normalized = normalize_text(text)
    if not normalized:
        return ChangePredictionResult(None, normalized, "empty_prediction", "unresolved")

    binary = _binary_change_value(normalized)
    if binary is not None:
        return ChangePredictionResult(binary, normalized, None, "explicit_binary_text")

    candidate = _ANSWER_PREFIX_PATTERN.sub("", normalized, count=1)
    binary = _binary_change_value(candidate)
    if binary is not None:
        return ChangePredictionResult(binary, normalized, None, "explicit_binary_text")

    payload = extract_json_object(text).payload
    if payload is not None:
        for key in _STRUCTURED_CHANGE_KEYS:
            if key not in payload:
                continue
            binary = _binary_change_value(payload[key])
            if binary is not None:
                return ChangePredictionResult(
                    binary,
                    normalized,
                    None,
                    "explicit_structured_binary",
                )
    return ChangePredictionResult(None, normalized, "explicit_binary_unresolved", "unresolved")


def _is_complete_no_change_clause(text: str) -> bool:
    candidate = _ANSWER_PREFIX_PATTERN.sub("", normalize_text(text), count=1)
    return bool(candidate) and (
        candidate in _CONTEXTUAL_NO_CHANGE_EXPRESSIONS
        or any(pattern.fullmatch(candidate) for pattern in _NO_CHANGE_PATTERNS)
    )


def _has_contextual_no_change_decision(text: str) -> bool:
    normalized = normalize_text(text)
    has_no_change_cue = any(
        pattern.search(normalized) for pattern in _CONTEXTUAL_NO_CHANGE_PATTERNS
    )
    has_positive_evidence = any(
        pattern.search(normalized) for pattern in _POSITIVE_CHANGE_EVIDENCE_PATTERNS
    )
    return has_no_change_cue and not has_positive_evidence


def parse_change_prediction_contextual_v3(text: str) -> ChangePredictionResult:
    """Parse LEVIR captions with the versioned contextual semantic rules."""

    normalized = normalize_text(text)
    if not normalized:
        return ChangePredictionResult(None, normalized, "empty_prediction", "unresolved")

    binary = _binary_change_value(normalized)
    if binary is not None:
        return ChangePredictionResult(binary, normalized, None, "binary_literal")

    payload = extract_json_object(text).payload
    if payload is not None:
        for key in _STRUCTURED_CHANGE_KEYS:
            if key not in payload:
                continue
            binary = _binary_change_value(payload[key])
            if binary is not None:
                return ChangePredictionResult(binary, normalized, None, "structured_binary")

    candidate = _ANSWER_PREFIX_PATTERN.sub("", normalized, count=1)
    if candidate in _CONTEXTUAL_NO_CHANGE_EXPRESSIONS:
        return ChangePredictionResult(0, normalized, None, "exact_no_change")
    if any(pattern.fullmatch(candidate) for pattern in _NO_CHANGE_PATTERNS):
        return ChangePredictionResult(0, normalized, None, "pattern_no_change")

    clauses = [
        clause
        for clause in _CLAUSE_SEPARATOR_PATTERN.split(text)
        if normalize_text(clause)
    ]
    if len(clauses) > 1 and all(_is_complete_no_change_clause(clause) for clause in clauses):
        return ChangePredictionResult(0, normalized, None, "composite_no_change")
    if _has_contextual_no_change_decision(text):
        return ChangePredictionResult(0, normalized, None, "contextual_no_change")
    return ChangePredictionResult(1, normalized, None, "default_change")


def parse_change_prediction(text: str) -> ChangePredictionResult:
    """把 LEVIR-CC 自然语言输出解析为 0=无变化、1=发生变化。

    无变化只接受完整标准化表达，避免把包含否定词的复合变化描述误判为无变化。
    """

    normalized = normalize_text(text)
    if not normalized:
        return ChangePredictionResult(None, normalized, "empty_prediction")
    return ChangePredictionResult(
        0 if normalized in _NO_CHANGE_EXPRESSIONS else 1,
        normalized,
        None,
    )


def text_tokens(text: str) -> list[str]:
    return re.findall(r"[\u4e00-\u9fff]|[A-Za-z0-9_]+", text.lower())
